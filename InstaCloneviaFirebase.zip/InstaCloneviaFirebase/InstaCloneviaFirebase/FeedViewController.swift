//
//  FeedViewController.swift
//  InstaCloneviaFirebase
//
//  Created by Eray Sen on 5.07.2020.
//  Copyright © 2020 Eray Sen. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage

class FeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var userEmailArray = [String]()
    var commentArray = [String]()
    var likesArray = [Int]()
    var userImageArray = [String]()
    var documentIDArray = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        getDataFromFirestore()
        
        // PUSH NOTIFICATON İŞLEMLERİ BURADA YAPILACAK
        /* OneSignal'i import edeceğiz
        - playerID alacağız
        - Önce kullanıcı bildirime izin verdi mi onu kontrol edeceğiz
    let status : OSPermissionSubscriptionState = OneSignal.getPermissionSubcState()
    let playerID = status.subscriptionStatus.userid  // bize string veriyor
         
         // Firebase'e yeni bir koleksiyon açarak user'ın ID ve Email'ini kaydederiz
         // Aşağıyı optional'dan kurtarmak için eğer playerNewID'ye atılabiliyorsa yani vars devam ediyoruz.
         
    if let playerNewID = playerID {
    let firestoreReferences = Firestore.firestore()
         
    let playerIDDict = ["email" : Auth.auth().currentUser!.email!,
         "playerID" : playerNewID] as! [String : Any]
    firestoreReferences.collection("PlayerID").addDocument(data: playerIDDict, )
         
         }
         
         
         
        */
    }
    
    func getDataFromFirestore(){
        let firestoreDatabase = Firestore.firestore()
        firestoreDatabase.collection("posts").order(by: "date", descending: true).addSnapshotListener { (snapshot, error) in
            if error != nil{
                print(error?.localizedDescription ?? "Error!")
            }else {
                if snapshot?.isEmpty != true {
                    
                    self.userEmailArray.removeAll(keepingCapacity: false)
                    self.commentArray.removeAll(keepingCapacity: false)
                    self.likesArray.removeAll(keepingCapacity: false)
                    self.userImageArray.removeAll(keepingCapacity: false)
                    
                    for document in snapshot!.documents{
                        let documentID = document.documentID
                        self.documentIDArray.append(documentID)
                        
                        if let postedBy = document.get("postedBy") as? String{
                            self.userEmailArray.append(postedBy)
                        }
                        if let postComment = document.get("postComment") as? String{
                            self.commentArray.append(postComment)
                        }
                        if let likes = document.get("likes") as? Int{
                            self.likesArray.append(likes)
                        }
                        if let imageUrl = document.get("imageUrl") as? String{
                            self.userImageArray.append(imageUrl)
                        }
                        
                    }
                    self.tableView.reloadData()
                    
                }
                
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userEmailArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! FeedCellTableViewCell
        cell.userEmailLabel.text = userEmailArray[indexPath.row]
        cell.likeLabel.text = String(likesArray[indexPath.row])
        cell.commentLabel.text = commentArray[indexPath.row]
        //cell.userImageView.sd_setImage(with: URL(string: self.userImageArray[indexPath.row]))
        cell.userImageView.image = UIImage(named: "selectImage.png")
        cell.documentIDLabel.text = documentIDArray[indexPath.row]
        
        return cell
        }
        
        // SD Image çalışmıyor görselleri çekemiyorum.
    
      
    }


