//
//  ViewController.swift
//  InstaCloneviaFirebase
//
//  Created by Eray Sen on 4.07.2020.
//  Copyright © 2020 Eray Sen. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {
    @IBOutlet weak var emailText: UITextField!
    
    @IBOutlet weak var passwordText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func signInClicked(_ sender: Any) {
        if emailText.text != "" && passwordText.text != ""{
        Auth.auth().signIn(withEmail: emailText.text!, password: passwordText.text!) { (authData, error) in
            if error != nil {
                self.makeAlert(titleInput: "Error!", messageInput: error?.localizedDescription ?? "Error!")
            } else{
                self.performSegue(withIdentifier: "toFeedVC", sender: nil)
            }
        }
            }else{
            makeAlert(titleInput: "Error!", messageInput: "Email/Password Hatası!")
        }
        
    }
    @IBAction func signUpClicked(_ sender: Any) { // emaillerin boş olmasına karşılık bir kontrol ekliyouruz.
        
        if emailText.text != "" && passwordText.text != ""{
            Auth.auth().createUser(withEmail: emailText.text!, password: passwordText.text!) { (authData, error) in
                //Yukarıdaki işlem sonucu eğer hata gelirse diye ilk onu değerlendiriyoruz.
                if error != nil{
                    self.makeAlert(titleInput: "Error!", messageInput: error?.localizedDescription ?? "Error!")
                
                }else {
                    self.performSegue(withIdentifier: "toFeedVC", sender: nil)
                }
            }
        
        }else {
            makeAlert(titleInput: "Error!", messageInput: "Email/Password Hatası")
        }
    }
    
    func makeAlert(titleInput: String, messageInput: String){
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "OK!", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
}

