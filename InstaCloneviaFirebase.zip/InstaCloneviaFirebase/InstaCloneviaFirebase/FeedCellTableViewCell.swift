//
//  FeedCellTableViewCell.swift
//  InstaCloneviaFirebase
//
//  Created by Eray Sen on 7.07.2020.
//  Copyright © 2020 Eray Sen. All rights reserved.
//

import UIKit
import Firebase

class FeedCellTableViewCell: UITableViewCell {
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userEmailLabel: UILabel!
    @IBOutlet weak var commentLabel: UILabel!
    @IBOutlet weak var likeLabel: UILabel!
    @IBOutlet weak var documentIDLabel: UILabel!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        // Initialization code
    }
    
    

    @IBAction func likeButtonClicked(_ sender: Any) {
        let firestoreDatabase = Firestore.firestore()
        
        // setData kullanarak yeni like sayısını database'e yeniden yüklüyorum.
        if let likeCount = Int(likeLabel.text!){
            let likeStore = ["likes" : likeCount + 1] as [String : Any]
            firestoreDatabase.collection("posts").document(documentIDLabel.text!).setData(likeStore, merge: true)
            }
        
        
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
